#!/bin/sh

node ./scripts/check.i18n.mjs
