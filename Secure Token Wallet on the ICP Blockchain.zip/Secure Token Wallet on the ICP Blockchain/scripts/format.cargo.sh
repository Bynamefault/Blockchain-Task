#!/usr/bin/env bash

cargo sort --grouped --workspace
