#!/usr/bin/env bash

dfx deploy signer --network "${ENV:-local}"
