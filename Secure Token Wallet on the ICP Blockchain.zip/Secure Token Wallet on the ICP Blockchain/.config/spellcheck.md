# Spell checking

A custom dictionary is available containing terms used in this project but not (yet) widely recognized in English.

The dictionary is in the `hunspell` format. This is widely recognized and will probably work with your spell checker of choice.

## Dictionary format

See [`hunspell`'s man page](https://manpages.ubuntu.com/manpages/focal/man5/hunspell.5.html) and the [`nuspell` documentation with examples](https://github.com/nuspell/nuspell/wiki/Dictionary-File-Format).
