<script lang="ts">
	import type { OptionToken } from '$lib/types/token';

	export const token: OptionToken = undefined;
</script>

<slot />
