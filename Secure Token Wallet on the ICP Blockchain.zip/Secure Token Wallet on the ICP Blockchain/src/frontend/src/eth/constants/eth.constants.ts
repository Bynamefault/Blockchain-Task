export const ETH_BASE_FEE = 21_000n;
