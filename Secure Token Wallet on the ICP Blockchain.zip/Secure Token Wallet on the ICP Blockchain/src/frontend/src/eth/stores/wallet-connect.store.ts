import { writable } from 'svelte/store';

export const walletConnectPaired = writable(false);
