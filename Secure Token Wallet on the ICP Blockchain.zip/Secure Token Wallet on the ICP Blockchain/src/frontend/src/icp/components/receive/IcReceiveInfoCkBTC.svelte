<script lang="ts">
	import { nonNullish } from '@dfinity/utils';
	import { BigNumber } from '@ethersproject/bignumber';
	import { createEventDispatcher, getContext } from 'svelte';
	import { fade } from 'svelte/transition';
	import { BTC_DECIMALS } from '$env/tokens.btc.env';
	import IcReceiveWalletAddress from '$icp/components/receive/IcReceiveWalletAddress.svelte';
	import { btcAddressStore } from '$icp/stores/btc.store';
	import { ckBtcMinterInfoStore } from '$icp/stores/ckbtc.store';
	import {
		RECEIVE_TOKEN_CONTEXT_KEY,
		type ReceiveTokenContext
	} from '$icp/stores/receive-token.store';
	import ReceiveAddress from '$lib/components/receive/ReceiveAddress.svelte';
	import ContentWithToolbar from '$lib/components/ui/ContentWithToolbar.svelte';
	import Hr from '$lib/components/ui/Hr.svelte';
	import { i18n } from '$lib/stores/i18n.store';
	import { formatToken } from '$lib/utils/format.utils';
	import { replacePlaceholders } from '$lib/utils/i18n.utils';

	const { tokenId, close } = getContext<ReceiveTokenContext>(RECEIVE_TOKEN_CONTEXT_KEY);

	const dispatch = createEventDispatcher();

	const displayQRCode = (address: string) =>
		dispatch('icQRCode', {
			address,
			addressLabel: $i18n.receive.bitcoin.text.bitcoin_address
		});

	let btcAddress: string | undefined = undefined;
	$: btcAddress = $btcAddressStore?.[$tokenId]?.data;

	let kytFee: bigint | undefined = undefined;
	$: kytFee = $ckBtcMinterInfoStore?.[$tokenId]?.data.kyt_fee;
</script>

<ContentWithToolbar>
	<IcReceiveWalletAddress on:icQRCode />

	{#if nonNullish(btcAddress)}
		<div class="mb-6">
			<Hr />
		</div>

		<ReceiveAddress
			labelRef="bitcoin-address"
			address={btcAddress}
			qrCodeAriaLabel={$i18n.receive.bitcoin.text.display_bitcoin_address_qr}
			copyAriaLabel={$i18n.receive.bitcoin.text.bitcoin_address_copied}
			on:click={() => displayQRCode(btcAddress ?? '')}
		>
			<svelte:fragment slot="title">{$i18n.receive.bitcoin.text.bitcoin_address}</svelte:fragment>
			<svelte:fragment slot="text"
				>{$i18n.receive.bitcoin.text.from_network}&nbsp;{#if nonNullish(kytFee)}<span in:fade
						>{replacePlaceholders($i18n.receive.bitcoin.text.fee_applied, {
							$fee: formatToken({
								value: BigNumber.from(kytFee),
								unitName: BTC_DECIMALS,
								displayDecimals: BTC_DECIMALS
							})
						})}</span
					>{/if}
			</svelte:fragment>
		</ReceiveAddress>
	{/if}

	<button class="primary full center text-center" on:click={close} slot="toolbar"
		>{$i18n.core.text.done}</button
	>
</ContentWithToolbar>
