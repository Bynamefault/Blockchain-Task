<script lang="ts">
	import IcSendModal from '$icp/components/send/IcSendModal.svelte';
	import ConvertETH from '$icp-eth/components/send/ConvertETH.svelte';
	import {
		ckEthereumTwinTokenNetworkId,
		ckEthereumTwinToken,
		ckEthereumNativeTokenId,
		ckEthereumNativeToken
	} from '$icp-eth/derived/cketh.derived';
	import IconConvert from '$lib/components/icons/IconConvert.svelte';
	import { ethAddress } from '$lib/derived/address.derived';
	import { modalConvertToTwinTokenEth } from '$lib/derived/modal.derived';
	import { i18n } from '$lib/stores/i18n.store';
	import { replacePlaceholders } from '$lib/utils/i18n.utils';
</script>

<ConvertETH
	nativeTokenId={$ckEthereumNativeTokenId}
	nativeNetworkId={$ckEthereumNativeToken.network.id}
	ariaLabel={replacePlaceholders($i18n.convert.text.convert_to_token, {
		$token: $ckEthereumTwinToken.symbol
	})}
>
	<IconConvert size="28" slot="icon" />
	<span
		>{replacePlaceholders($i18n.convert.text.convert_to_token, {
			$token: $ckEthereumTwinToken.symbol
		})}</span
	>
</ConvertETH>

{#if $modalConvertToTwinTokenEth}
	<IcSendModal networkId={$ckEthereumTwinTokenNetworkId} destination={$ethAddress ?? ''} />
{/if}
