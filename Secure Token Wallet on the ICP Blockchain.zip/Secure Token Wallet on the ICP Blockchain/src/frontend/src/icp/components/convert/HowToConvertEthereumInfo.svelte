<script lang="ts">
	import { createEventDispatcher, getContext } from 'svelte';
	import { tokenCkErc20Ledger } from '$icp/derived/ic-token.derived';
	import {
		ckEthereumNativeToken,
		ckEthereumNativeTokenBalance,
		ckEthereumTwinToken
	} from '$icp-eth/derived/cketh.derived';
	import { SEND_CONTEXT_KEY, type SendContext } from '$icp-eth/stores/send.store';
	import ReceiveAddress from '$lib/components/receive/ReceiveAddress.svelte';
	import ContentWithToolbar from '$lib/components/ui/ContentWithToolbar.svelte';
	import Value from '$lib/components/ui/Value.svelte';
	import { ZERO } from '$lib/constants/app.constants';
	import { ethAddress } from '$lib/derived/address.derived';
	import { tokenWithFallback } from '$lib/derived/token.derived';
	import { i18n } from '$lib/stores/i18n.store';
	import { modalStore } from '$lib/stores/modal.store';
	import { formatToken } from '$lib/utils/format.utils';
	import { replaceOisyPlaceholders, replacePlaceholders } from '$lib/utils/i18n.utils';

	export let formCancelAction: 'back' | 'close' = 'back';

	let ckErc20 = false;
	$: ckErc20 = $tokenCkErc20Ledger;

	const dispatch = createEventDispatcher();

	const { sendBalance, sendTokenDecimals, sendToken } = getContext<SendContext>(SEND_CONTEXT_KEY);
</script>

<ContentWithToolbar>
	<div>
		<p>
			{replacePlaceholders(
				replaceOisyPlaceholders($i18n.convert.text.how_to_convert_eth_to_cketh),
				{
					$token: $ckEthereumTwinToken.symbol,
					$ckToken: $tokenWithFallback.symbol
				}
			)}:
		</p>
	</div>

	{#if ckErc20}
		<div class="bg-light-blue p-4 mt-2 mb-4 rounded-lg">
			<p class="break-normal font-bold">
				{replacePlaceholders($i18n.convert.text.check_balance_for_fees, {
					$token: $ckEthereumNativeToken.symbol
				})}
			</p>

			<p class="break-normal">
				{replacePlaceholders($i18n.convert.text.fees_explanation, {
					$token: $ckEthereumNativeToken.symbol
				})}
			</p>

			<p class="break-normal pt-4">
				{$i18n.convert.text.current_balance}&nbsp;<output class="font-bold"
					>{formatToken({
						value: $ckEthereumNativeTokenBalance ?? ZERO,
						unitName: $ckEthereumNativeToken.decimals
					})}
					{$ckEthereumNativeToken.symbol}</output
				>
			</p>
		</div>
	{/if}

	<div class="grid grid-cols-[1fr_auto] gap-x-4 mt-4">
		<div class="overflow-hidden flex flex-col gap-2 items-center mb-2">
			<span
				class="inline-flex items-center justify-center text-xs font-bold p-2.5 w-4 h-4 text-misty-rose border-[1.5px] rounded-full"
				>1</span
			>

			<div class="h-full w-[1.5px] bg-misty-rose"></div>
		</div>

		<ReceiveAddress
			labelRef="eth-wallet-address"
			address={$ethAddress ?? ''}
			qrCodeAriaLabel={$i18n.wallet.text.display_wallet_address_qr}
			copyAriaLabel={$i18n.wallet.text.wallet_address_copied}
			on:click={() => dispatch('icQRCode')}
		>
			<svelte:fragment slot="title"
				>{replacePlaceholders(replaceOisyPlaceholders($i18n.convert.text.send_eth), {
					$token: $ckEthereumTwinToken.symbol
				})}</svelte:fragment
			>
		</ReceiveAddress>

		<div class="overflow-hidden flex flex-col gap-2 items-center mb-2">
			<span
				class="inline-flex items-center justify-center text-xs font-bold p-2.5 w-4 h-4 text-misty-rose border-[1.5px] rounded-full"
				>2</span
			>

			<div class="h-full w-[1.5px] bg-misty-rose"></div>
		</div>

		<div>
			<Value element="div">
				<svelte:fragment slot="label"
					>{replacePlaceholders($i18n.convert.text.wait_eth_current_balance, {
						$token: $ckEthereumTwinToken.symbol
					})}</svelte:fragment
				>

				<p class="mb-6">
					{formatToken({
						value: $sendBalance ?? ZERO,
						unitName: $sendTokenDecimals,
						displayDecimals: $sendTokenDecimals
					})}
					{$sendToken.symbol}
				</p>
			</Value>
		</div>

		<div class="flex justify-center">
			<span
				class="inline-flex items-center justify-center text-xs font-bold p-2.5 w-4 h-4 text-misty-rose border-[1.5px] rounded-full"
				>3</span
			>
		</div>

		<div>
			<Value element="div">
				<svelte:fragment slot="label"
					>{replacePlaceholders($i18n.convert.text.convert_eth_to_cketh, {
						$token: $ckEthereumTwinToken.symbol,
						$ckToken: $tokenWithFallback.symbol
					})}</svelte:fragment
				>

				<button class="secondary full center mt-3 mb-4" on:click={() => dispatch('icConvert')}>
					<span class="text-dark-slate-blue font-bold">{$i18n.convert.text.set_amount}</span>
				</button>
			</Value>
		</div>
	</div>

	<div slot="toolbar">
		{#if formCancelAction === 'back'}
			<button
				type="button"
				class="primary full center text-center"
				on:click={() => dispatch('icBack')}>{$i18n.core.text.back}</button
			>
		{:else}
			<button type="button" class="primary full center text-center" on:click={modalStore.close}
				>{$i18n.core.text.done}</button
			>
		{/if}
	</div>
</ContentWithToolbar>
