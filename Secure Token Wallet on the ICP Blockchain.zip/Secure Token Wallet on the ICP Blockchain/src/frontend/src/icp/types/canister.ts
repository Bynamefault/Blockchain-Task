import type { CanisterIdText } from '$lib/types/canister';

export type LedgerCanisterIdText = CanisterIdText;
export type IndexCanisterIdText = CanisterIdText;
export type MinterCanisterIdText = CanisterIdText;
