// Worker refresh rate
export const BTC_STATUSES_TIMER_INTERVAL_MILLIS = 'disabled';
export const CKBTC_UPDATE_BALANCE_TIMER_INTERVAL_MILLIS = 60000;
export const CKBTC_MINTER_INFO_TIMER = 'disabled';
