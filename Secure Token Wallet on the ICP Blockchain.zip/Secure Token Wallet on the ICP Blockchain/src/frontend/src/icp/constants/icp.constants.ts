export const ICP_TRANSACTION_FEE_E8S = 10_000n;
export const ICP_FEE_DECIMALS = 8;
