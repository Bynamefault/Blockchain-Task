// TODO: to be removed when we have finished implementing all the OnRamper features
export const ONRAMPER_ENABLED = JSON.parse(import.meta.env.VITE_ONRAMPER_ENABLED ?? false) === true;
