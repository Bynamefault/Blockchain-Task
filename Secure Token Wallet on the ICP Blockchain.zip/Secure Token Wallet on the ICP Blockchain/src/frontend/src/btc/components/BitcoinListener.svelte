<!-- TODO: Implement https://dfinity.atlassian.net/browse/GIX-2884 -->
<slot />
